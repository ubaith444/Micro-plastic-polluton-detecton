# UPD > 2022-07-24 12:50am
https://universe.roboflow.com/object-detection/upd

Provided by Roboflow
License: CC BY 4.0

